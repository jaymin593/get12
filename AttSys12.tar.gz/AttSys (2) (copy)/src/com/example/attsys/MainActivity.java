package com.example.attsys;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
 


public class MainActivity extends Activity implements AnimationListener {

	private boolean mIsBackButtonPressed;
    private static final int SPLASH_DURATION = 4000; //3 seconds
    private Handler myhandler;
  

	ImageView img;
	Animation animt;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splashscreen);

		img = (ImageView) findViewById(R.id.growmore);
		

		// load the animation
		animt = AnimationUtils.loadAnimation(getApplicationContext(),
				R.animator.rotate);
		
		img.setVisibility(View.VISIBLE);
		
		// start the animation
		img.startAnimation(animt);
		
		 myhandler = new Handler();
		  
	        // run a thread to start the home screen
	        myhandler.postDelayed(new Runnable()
	        {
	            @Override
	            public void run()
	            {
	  
	               finish();
	                 
	               if (!mIsBackButtonPressed)
	               {
	                    // start the home activity
	                    Intent intent = new Intent(MainActivity.this, Login.class);
	                    MainActivity.this.startActivity(intent);
	               }
	                  
	            }
	  
	        }, SPLASH_DURATION);
	    }


	@Override
	public void onAnimationEnd(Animation arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onAnimationRepeat(Animation arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onAnimationStart(Animation arg0) {
		// TODO Auto-generated method stub
		
	}
}